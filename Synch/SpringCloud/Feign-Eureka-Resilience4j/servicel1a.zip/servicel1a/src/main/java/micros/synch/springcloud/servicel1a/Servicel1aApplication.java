package micros.synch.springcloud.servicel1a;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Servicel1aApplication {

	public static void main(String[] args) {
		SpringApplication.run(Servicel1aApplication.class, args);
	}

}
