package micros.synch.springcloud.servicel2a;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Servicel2aApplicationTests {

	@Test
	void contextLoads() {
	}

}
