package micros.synch.springboot.servicel1a;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Servicel1aApplicationTests {

	@Test
	void contextLoads() {
	}

}
