package micros.synch.springboot.servicel2a;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Servicel2aApplication {

	public static void main(String[] args) {
		SpringApplication.run(Servicel2aApplication.class, args);
	}

}
